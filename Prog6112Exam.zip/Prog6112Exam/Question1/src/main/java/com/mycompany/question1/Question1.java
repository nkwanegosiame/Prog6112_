/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1;
import java.util.Scanner;
import java.ArrayList;
import java.List;


/**
 *
 * @author Student
 */
public class Question1 {
    
    const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Helper function to prompt user input asynchronously
const askQuestion = (query) => {
    return new Promise((resolve) => rl.question(query, resolve));
};

async function generateSalesReport() {
    const products = [
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
    ];
    
    const months = 3;
    let totalSales = 0;
    let highestSale = 0;
    let mostPopularProduct = "";

    // Loop through each product and each month to gather sales data
    for (let i = 0; i < products.length; i++) {
        for (let month = 1; month <= months; month++) {
            const answer = await askQuestion(
                `Enter number of sales for month ${month} for ${products[i]} mattress: `
            );
            
            const sales = parseInt(answer, 10) || 0;
            totalSales += sales;

            // Check for the highest single-month sale to match the sample output
            if (sales > highestSale) {
                highestSale = sales;
                mostPopularProduct = products[i];
            }
        }
        console.log(); // Blank line between products as shown in sample
    }

    // Calculate average across all 9 entries (3 products * 3 months = 153 / 9 = 17)
    const totalEntries = products.length * months;
    const averageSales = Math.round(totalSales / totalEntries);

    // Display the final report
    console.log("PRODUCT SALES REPORT - 2026");
    console.log("****************");
    console.log(TOTAL PRODUCT SALES: ${totalSales});
    console.log(AVERAGE PRODUCT SALES: ${averageSales});
    console.log(MOST POPULAR PRODUCT: ${mostPopularProduct}(${highestSale}));

    rl.close();

    generateSalesReort();
    
    // Class product that includes distint methods.
    public class Product() {
     public interface IProduct{
        int GetTotalProductsSold();
        double GetAvarageProductSold();
        String GetMostPopularProduct();
     }
    }
    
    // Classs that is responsible for printing the necessary data for the report
    
    public class PrintProduct {
        constructor(products = []) {
            this.products = products;
        }
        
        // Prints a complete sales report combining all metrics
        printReport(){
            console.log("=== PRODUCT SALES REORT ===");
            if(this.products.length === 0) {
                console.log("No product data avalaible.");
                return;
            }
        }
    }
}

