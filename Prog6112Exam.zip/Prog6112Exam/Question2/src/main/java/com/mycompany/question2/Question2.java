/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * @author Student
 */

public class Question2 {

 public class ProductApp extends JFrame {
    // GUI Components
    private JTextField txtCustomerName;
    private JComboBox<String> cmbProduct;
    private JTextField txtPrice;
    private JButton btnProcess;
    private JTextArea txtDisplay;

    // Menu Components
    private JMenuBar menuBar;
    private JMenu fileMenu, editMenu;
    private JMenuItem exitItem, processItem, clearItem, saveItem;

    public ProductApp() {
        // Frame Setup
        setTitle("Product App");
        setSize(450, 480);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); // Using null layout to match the exact visual positioning

        // Menu Bar Setup
        menuBar = new JMenuBar();
        
        fileMenu = new JMenu("File");
        exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        editMenu = new JMenu("Edit");
        processItem = new JMenuItem("Process");
        clearItem = new JMenuItem("Clear");
        saveItem = new JMenuItem("Save");

        processItem.addActionListener(e -> processSale());
        clearItem.addActionListener(e -> clearFields());
        saveItem.addActionListener(e -> saveToFile());

        editMenu.add(processItem);
        editMenu.add(clearItem);
        editMenu.add(saveItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        setJMenuBar(menuBar);

        // Labels and Input Fields
        JLabel lblCustomer = new JLabel("Customer Name:");
        lblCustomer.setBounds(40, 30, 120, 25);
        add(lblCustomer);

        txtCustomerName = new JTextField();
        txtCustomerName.setBounds(180, 30, 200, 25);
        add(txtCustomerName);

        JLabel lblProduct = new JLabel("Select Product:");
        lblProduct.setBounds(40, 75, 120, 25);
        add(lblProduct);

        String[] products = {"Cozy Nights Monarch", "DreamRest Orthopedic", "CloudNine Deluxe"};
        cmbProduct = new JComboBox<>(products);
        cmbProduct.setBounds(180, 75, 200, 25);
        add(cmbProduct);

        JLabel lblPrice = new JLabel("Enter Price:");
        lblPrice.setBounds(40, 120, 120, 25);
        add(lblPrice);

        txtPrice = new JTextField();
        txtPrice.setBounds(180, 120, 200, 25);
        add(txtPrice);

        // Process Button
        btnProcess = new JButton("PROCESS");
        btnProcess.setBounds(120, 170, 200, 30);
        btnProcess.addActionListener(e -> processSale());
        add(btnProcess);

        // Display Area for Results
        txtDisplay = new JTextArea();
        txtDisplay.setEditable(false);
        txtDisplay.setBorder(BorderFactory.createTitledBorder("Sale Details"));
        JScrollPane scrollPane = new JScrollPane(txtDisplay);
        scrollPane.setBounds(40, 220, 340, 170);
        add(scrollPane);
    }

    // Method to calculate and display sale details
    private void processSale() {
        String customerName = txtCustomerName.getText().trim();
        String productName = (String) cmbProduct.getSelectedItem();
        String priceText = txtPrice.getText().trim();

        // Basic validation
        if (customerName.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double price = Double.parseDouble(priceText);

            // Calculation Requirements
            double vatAmount = price * 0.15;
            double commissionAmount = price * 0.05;
            double totalSaleAmount = price + vatAmount + commissionAmount;

            // Format output
            String output = String.format(
                "Customer Name: %s\n" +
                "Product Name: %s\n" +
                "Product Price: R %.2f\n" +
                "VAT Amount (15%%): R %.2f\n" +
                "Commission Amount (5%%): R %.2f\n" +
                "Total Sale Amount: R %.2f",
                customerName, productName, price, vatAmount, commissionAmount, totalSaleAmount
            );

            txtDisplay.setText(output);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid numeric price.", "Format Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to clear all fields
    private void clearFields() {
        txtCustomerName.setText("");
        cmbProduct.setSelectedIndex(0);
        txtPrice.setText("");
        txtDisplay.setText("");
    }

    // Method to save the displayed details to a text file
    private void saveToFile() {
        if (txtDisplay.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No data to save. Please process a sale first.", "Save Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("sales_report.txt", true))) {
            writer.write(txtDisplay.getText());
            writer.write("\n----------------------------------------\n");
            JOptionPane.showMessageDialog(this, "Sale details saved to sales_report.txt", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Class named ProductCaculations 
    public class ProductCaculations() {
        public interface IProductCalcuations {
            double GetVat();
            double GetCommission();
            double GetTotal();
        }
    }
  }   
}
